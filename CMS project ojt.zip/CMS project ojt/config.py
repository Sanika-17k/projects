class Config:
    SECRET_KEY = '4bae41d5711052f5b1d411f8bdb1c12c'
    SQLALCHEMY_DATABASE_URI = 'sqlite:///site.db'
    SQLALCHEMY_TRACK_MODIFICATIONS = False
